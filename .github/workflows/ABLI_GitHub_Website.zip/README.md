# Above & Beyond Leadership Institute (ABLI) Website

Professional single-page site ready for deployment.

## Preview

![Hero](assets/screenshots/hero.png)

![About](assets/screenshots/about.png)

![Services](assets/screenshots/services.png)

![Values](assets/screenshots/values.png)

![Contact](assets/screenshots/contact.png)

---

## Deploy

### Netlify
1. Drag & drop the contents of this folder to https://app.netlify.com/drop

### GitHub Pages
1. Create a repository on GitHub
2. Push files to `main` branch
3. Enable Pages in repository settings

---

## Contact
contactabli.info@gmail.com
+254 759 395 554
